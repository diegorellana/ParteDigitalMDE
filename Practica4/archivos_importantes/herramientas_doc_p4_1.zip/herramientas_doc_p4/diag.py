# Genera el diagrama RTL de binary_to_bcd en SVG
W,H=2340,860
o=[]
def add(s): o.append(s)
NAVY='#0b2a4a'; BLUE='#1d5fa6'; GREEN='#2e7d32'; BROWN='#7a4a1e'; ORANGE='#d9822b'; CLOUDF='#dcecf7'; CLOUDS='#2a7aa8'
F="font-family:'DejaVu Sans Mono',monospace"
def text(x,y,s0,size=15,color=NAVY,anchor='middle',weight='normal',italic=False):
    s=str(s0).replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
    st='font-style:italic;' if italic else ''
    add(f'<text x="{x}" y="{y}" font-size="{size}" fill="{color}" text-anchor="{anchor}" font-weight="{weight}" style="{F};{st}">{s}</text>')
def reg(x,y,w,h,title,lines):
    add(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="3" fill="white" stroke="{NAVY}" stroke-width="2"/>')
    add(f'<path d="M{x},{y+h-24} L{x+13},{y+h-14} L{x},{y+h-4}" fill="none" stroke="{NAVY}" stroke-width="1.6"/>')
    text(x+18,y+h-9,'clk',12,NAVY,'start')
    text(x+w/2,y-8,title,14,NAVY,'middle','bold')
    for i,l in enumerate(lines): text(x+w/2,y+h/2-(len(lines)-1)*9+i*18+5,l,14)
def cloud(cx,cy,rx,ry,label,sub=None):
    import math
    n=9; pts=[]
    for k in range(n):
        a=2*math.pi*k/n
        pts.append((cx+rx*math.cos(a),cy+ry*math.sin(a)))
    d=f'M{pts[0][0]:.1f},{pts[0][1]:.1f} '
    for k in range(n):
        p2=pts[(k+1)%n]; r=0.42*((rx+ry)/2)
        d+=f'A{r:.1f},{r:.1f} 0 0 1 {p2[0]:.1f},{p2[1]:.1f} '
    add(f'<path d="{d}Z" fill="{CLOUDF}" stroke="{CLOUDS}" stroke-width="2"/>')
    text(cx,cy+(0 if sub else 5),label,14,NAVY)
    if sub: text(cx,cy+18,sub,12,'#4a6a85')
def wire(pts,color,arrow=True,w=2.2,dash=False):
    d='M'+' L'.join(f'{x},{y}' for x,y in pts)
    m=' marker-end="url(#a%s)"'%color[1:] if arrow else ''
    da=' stroke-dasharray="7,5"' if dash else ''
    add(f'<path d="{d}" fill="none" stroke="{color}" stroke-width="{w}"{da}{m}/>')
def dot(x,y,c): add(f'<circle cx="{x}" cy="{y}" r="4" fill="{c}"/>')

add(f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">')
add('<defs>'+''.join(f'<marker id="a{c[1:]}" markerUnits="userSpaceOnUse" markerWidth="14" markerHeight="14" refX="13" refY="7" orient="auto"><path d="M0,0 L14,7 L0,14 z" fill="{c}"/></marker>' for c in [NAVY,BLUE,GREEN,BROWN,ORANGE])+'</defs>')
add(f'<rect width="{W}" height="{H}" fill="white"/>')
# marco
W=2340
o[0:0]=[]
FX,FY,FW,FH=170,70,1985,600
add(f'<rect x="{FX}" y="{FY}" width="{FW}" height="{FH}" rx="8" fill="none" stroke="{BROWN}" stroke-width="2.5"/>')
text(FX+FW/2,FY-12,'binary_to_bcd',18,BROWN,'middle','bold')
text(FX+FW/2,FY+24,"gen_binary_bw = 14 · gen_bcd_bw = 16 · gen_max_binary_value = 9999 · gen_pipeline = C_PIPELINE (14 bits a '1')",13,'#555')
YD=260; YV=560
wire([(20,YD),(205,YD)],BROWN); text(90,YD-10,'binary_in[13:0]',14,BROWN)
wire([(20,YV),(330,YV)],BROWN); text(80,YV-10,'valid_in',14,BROWN)
text(FX+15,FY+FH-15,'clk y reset_n (asíncrono) llegan a todos los registros',12,BROWN,'start',italic=True)
cloud(262,YD,55,42,'saturación','> 9999 → 9999')
wire([(317,YD),(350,YD)],BLUE)
reg(350,YD-40,130,80,'p_input_reg',['reg_binary_in','[13:0]'])
reg(330,YV-35,150,70,'p_input_reg',['reg_valid_in'])
def etapa(x0,I):
    cloud(x0+58,YD,58,44,f'normalizar {I}','+3 si ≥ 5')
    wire([(x0+116,YD),(x0+140,YD)],BLUE)
    cloud(x0+198,YD,58,44,f'desplazar {I}','<< 1')
    wire([(x0+256,YD),(x0+280,YD)],BLUE)
    reg(x0+278,YD-55,145,110,'p_pipeline_reg',[f'reg_pipeline({I})','bcd[15:0]','bin[13:0]'])
    text(x0+347,YD+75,f"gen_pipeline({I}) = '1'",12,ORANGE)
    return x0+415
wire([(480,YD),(530,YD)],BLUE)
text(480,YD+110,'entrada de la etapa 0: temp_bcd = 0, temp_binary_in = reg_binary_in',12,BLUE,'start')
x=etapa(530,0)
wire([(x,YD),(x+45,YD)],BLUE)
x=etapa(x+45,1)
wire([(x,YD),(x+30,YD)],BLUE)
text(x+60,YD+8,'· · ·',26,NAVY); text(x+60,YD+40,'etapas',12,'#555'); text(x+60,YD+56,'2 a 12',12,'#555')
wire([(x+90,YD),(x+115,YD)],BLUE)
x=etapa(x+115,13); xe=x
text(1000,YD-110,'s_entrada_pipeline(I+1) = s_salida_pipeline(I)',13,BLUE)
wire([(xe,YD),(xe+45,YD)],BLUE)
reg(xe+45,YD-40,135,80,'p_output_reg',['reg_bcd_out','[15:0]'])
xo=xe+180
wire([(xo,YD),(W-15,YD)],BROWN); text((FX+FW+W)/2,YD-10,'bcd_out[15:0]',14,BROWN)
wire([(480,YV),(600,YV)],GREEN); text(540,YV-10,'reg_valid_in',12,GREEN)
reg(600,YV-40,1060,80,'p_valid_delay_reg',['reg_valid_in_delayed[13:0]  (registro de desplazamiento de c_pipeline_delay = 14 bits)'])
wire([(1660,YV),(xe+45,YV)],GREEN); text((1660+xe+45)/2,YV-10,'reg_valid_in_delayed(13)',12,GREEN)
reg(xe+45,YV-35,135,70,'p_output_reg',['reg_valid_out'])
wire([(xo,YV),(W-15,YV)],BROWN); text((FX+FW+W)/2,YV-10,'valid_out',14,BROWN)
# leyenda
LX,LY=170,710
add(f'<rect x="{LX}" y="{LY}" width="1985" height="120" rx="6" fill="#fafafa" stroke="#bbb"/>')
text(LX+20,LY+28,'Leyenda',15,NAVY,'start','bold')
reg(LX+30,LY+48,70,50,'',[''])
text(LX+115,LY+78,'registro (proceso con reloj)',13,NAVY,'start')
cloud(LX+430,LY+72,48,30,'','')
text(LX+490,LY+78,'lógica combinacional',13,NAVY,'start')
wire([(LX+700,LY+50),(LX+770,LY+50)],BLUE); text(LX+780,LY+55,'path de datos (record t_pipeline_data)',13,NAVY,'start')
wire([(LX+700,LY+80),(LX+770,LY+80)],GREEN); text(LX+780,LY+85,'path de validación de salidas',13,NAVY,'start')
wire([(LX+700,LY+108),(LX+770,LY+108)],BROWN); text(LX+780,LY+113,'puertos de la entidad',13,NAVY,'start')
text(LX+1200,LY+55,"Cada etapa I: registro si gen_pipeline(I) = '1';",13,ORANGE,'start')
text(LX+1200,LY+77,"si vale '0', la salida del desplazamiento",13,ORANGE,'start')
text(LX+1200,LY+99,'pasa directa a la etapa siguiente.',13,ORANGE,'start')
add('</svg>')
open('diagrama_rtl_binary_to_bcd.svg','w').write('\n'.join(o))
