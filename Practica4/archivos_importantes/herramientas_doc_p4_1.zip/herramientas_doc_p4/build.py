import re,subprocess,json,sys,zipfile,shutil,os
import glob
SK=(glob.glob('/root/.claude/skills/**/docx', recursive=True) or [''])[0]  # carpeta de la skill docx
def build(pages):
    json.dump(pages,open('pages.json','w'))
    subprocess.run(['node','gen.js','pages.json'],check=True)
    z=zipfile.ZipFile('raw.docx'); files={n:z.read(n) for n in z.namelist()}
    d=files['word/document.xml'].decode()
    def fld(m):
        kind,n=m.group(1),m.group(2)
        return ('<w:r><w:fldChar w:fldCharType="begin"/></w:r>'
                f'<w:r><w:instrText xml:space="preserve"> SEQ {kind} \\* ARABIC </w:instrText></w:r>'
                '<w:r><w:fldChar w:fldCharType="separate"/></w:r>'
                f'<w:r><w:t>{n}</w:t></w:r><w:r><w:fldChar w:fldCharType="end"/></w:r>')
    d,c=re.subn(r'<w:r>(?:(?!<w:r>).)*?<w:t[^>]*>§SEQ:(\w+):(\d+)§</w:t></w:r>',fld,d,flags=re.S)
    assert '§' not in d, 'quedan marcas'
    files['word/document.xml']=d.encode()
    out='Respuestas_Practica4.docx'
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as zo:
        for n,b in files.items():
            if not n.endswith('/'): zo.writestr(n,b)
    subprocess.run(['python3',f'{SK}/scripts/office/soffice.py','--headless','--convert-to','pdf',out],check=True,capture_output=True)
    return c
def find_pages():
    H=json.load(open('headings.json'))
    n=int(re.search(r'Pages:\s+(\d+)',subprocess.run(['pdfinfo','Respuestas_Practica4.pdf'],capture_output=True,text=True).stdout).group(1))
    txt=[subprocess.run(['pdftotext','-f',str(p),'-l',str(p),'-layout','Respuestas_Practica4.pdf','-'],capture_output=True,text=True).stdout for p in range(1,n+1)]
    pages={}; cur=3  # empezar después del índice
    def norm(s): return re.sub(r'\s+',' ',s)
    for g in H:
        for key,t in [(g['h1'],g['h1'])]+[(g['h1']+'|'+s,s) for s in g['items']]:
            for p in range(cur,n+1):
                if any(norm(l).strip()==t for l in txt[p-1].splitlines()):
                    pages[key]=p; cur=p; break
            else: print('NO ENCONTRADO',t)
    return pages
c=build({}); p1=find_pages(); build(p1); p2=find_pages()
if p2!=p1: build(p2); p2=find_pages()
print('campos SEQ',c); print(json.dumps(p2,ensure_ascii=False,indent=0))
