// Genera Respuestas_Practica4.docx con el formato de la práctica 2.
// Uso: node gen.js paginas.json   (paginas.json: {"titulo de sección": página})
const fs = require('fs');
const {
  Document, Packer, Paragraph, TextRun, ImageRun, Table, TableRow, TableCell,
  AlignmentType, WidthType, BorderStyle, ShadingType, PageOrientation, Footer,
  PageNumber, TabStopType, PageBreak, HeadingLevel, VerticalAlign, SectionType,
} = require('docx');

const PAGES = fs.existsSync(process.argv[2] || '') ? JSON.parse(fs.readFileSync(process.argv[2])) : {};
const TNR = 'Times New Roman', MONO = 'Courier New';
const RED = 'C00000', CAPBLUE = '1F4E79';

// ---------- texto en línea: `código`, {{pendiente}}, **negrita**, _cursiva_
function runs(str, base = {}) {
  const out = [];
  const re = /(`[^`]+`|\{\{[^}]+\}\}|\*\*[^*]+\*\*)/g;
  let last = 0, m;
  while ((m = re.exec(str))) {
    if (m.index > last) out.push(new TextRun({ text: str.slice(last, m.index), font: TNR, ...base }));
    const t = m[0];
    if (t.startsWith('`')) out.push(new TextRun({ text: t.slice(1, -1), font: MONO, size: base.size ? base.size - 2 : 21 }));
    else if (t.startsWith('{{')) out.push(new TextRun({ text: t.slice(2, -2), font: TNR, color: RED, bold: true, ...base, }));
    else if (t.startsWith('**')) out.push(new TextRun({ ...base, text: t.slice(2, -2), font: TNR, bold: true }));
    last = m.index + t.length;
  }
  if (last < str.length) out.push(new TextRun({ text: str.slice(last), font: TNR, ...base }));
  return out;
}
const P = (s, opt = {}) => new Paragraph({
  children: runs(s), alignment: AlignmentType.JUSTIFIED,
  spacing: { before: 0, after: 140, line: 300 }, keepNext: /tabla \d/i.test(s), ...opt,
});
const H1s = [], H2s = [];
let curH1 = null;
const H1 = (s) => { H1s.push(s); curH1 = s; H2s.push({ h1: s, items: [] });
  return new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun({ text: s, font: TNR })] }); };
const H2 = (s) => { H2s[H2s.length - 1].items.push(s);
  return new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun({ text: s, font: TNR })] }); };
const BOX = (label, s) => new Paragraph({
  keepNext: true,
  border: { left: { style: BorderStyle.SINGLE, color: 'B00020', size: 18, space: 8 } },
  shading: { type: ShadingType.CLEAR, fill: 'F2F2F2', color: 'auto' },
  spacing: { before: 0, after: 200, line: 300 }, indent: { left: 200 }, alignment: AlignmentType.JUSTIFIED,
  children: [new TextRun({ text: label + ' ', font: TNR, bold: true }), ...runs(s)],
});
const BULLET = (s) => new Paragraph({ children: runs(s), numbering: { reference: 'bul', level: 0 },
  alignment: AlignmentType.JUSTIFIED, spacing: { after: 80, line: 280 } });
const CODE = (lines) => lines.map((l, i) => new Paragraph({
  keepNext: i < lines.length - 1,
  shading: { type: ShadingType.CLEAR, fill: 'F5F5F5', color: 'auto' },
  spacing: { before: i === 0 ? 60 : 0, after: i === lines.length - 1 ? 160 : 0, line: 240 },
  indent: { left: 300 },
  children: [new TextRun({ text: l.length ? l : ' ', font: MONO, size: 18 })],
}));

// Títulos de tabla y figura: estilo Caption con campo SEQ (se sustituye después)
let nTab = 0, nFig = 0;
const CAP = (kind, s) => {
  const n = kind === 'Tabla' ? ++nTab : ++nFig;
  return new Paragraph({ style: 'Caption', alignment: AlignmentType.CENTER,
    children: [new TextRun(`${kind} `), new TextRun(`§SEQ:${kind}:${n}§`), new TextRun(': '), ...runs(s, { italics: true, color: CAPBLUE, size: 20 })] });
};

// ---------- tablas
const bd = { style: BorderStyle.SINGLE, size: 4, color: '999999' };
function TABLE(widths, rows) {
  const total = widths.reduce((a, b) => a + b, 0);
  return new Table({
    width: { size: total, type: WidthType.DXA }, columnWidths: widths,
    alignment: AlignmentType.CENTER,
    rows: rows.map((r, ri) => new TableRow({
      tableHeader: ri === 0, cantSplit: true,
      children: r.map((c, ci) => new TableCell({
        width: { size: widths[ci], type: WidthType.DXA },
        borders: { top: bd, bottom: bd, left: bd, right: bd },
        shading: ri === 0 ? { type: ShadingType.CLEAR, fill: 'D9D9D9', color: 'auto' } : undefined,
        margins: { top: 60, bottom: 60, left: 100, right: 100 },
        verticalAlign: VerticalAlign.CENTER,
        children: [new Paragraph({ keepNext: true, spacing: { after: 0, line: 260 },
          alignment: ri === 0 ? AlignmentType.CENTER : AlignmentType.LEFT,
          children: runs(c, { size: 20, bold: ri === 0 }) })],
      })),
    })),
  });
}
// tabla + título debajo, sin separarse
const TAB = (widths, rows, cap) => [TABLE(widths, rows), CAP('Tabla', cap)];

// ================= CONTENIDO =================
const body = [];
const add = (...x) => x.flat().forEach((e) => body.push(e));

add(P('El conversor `binary_to_bcd` (archivo `rtl/binary_to_bcd.vhd`) se ha simulado con Questa y el banco de pruebas `testbench/tb_binary_to_bcd.vhd`. La síntesis con Design Compiler (librería `class.db`, reloj de 10 ns) y la implementación en la Basys 3 con Vivado se hacen en el laboratorio del 19 de noviembre. La tabla 1 recoge los datos de partida de la entrega y el archivo del que sale cada uno.'));
add(TAB([3600, 2900, 2526], [
  ['Dato', 'Valor', 'Fuente'],
  ['Latencia con `C_PIPELINE` todo a \'1\'', '16 ciclos (14 + 2)', 'transcript de Questa'],
  ['Conversiones comprobadas en simulación', '19387, 0 errores', 'transcript de Questa'],
  ['Biestables (DC)', '{{PENDIENTE}}', '`registros.rpt`'],
  ['Latches (DC)', '{{PENDIENTE}}', '`registros.rpt`'],
  ['Área total de celdas (DC)', '{{PENDIENTE}}', '`area.rpt`'],
  ['Slack del camino crítico (DC, T = 10 ns)', '{{PENDIENTE}}', '`timing.rpt`'],
  ['Slice LUTs y registros (Vivado)', '{{PENDIENTE}}', 'Utilization - Place Design'],
  ['WNS en la Basys 3 (Vivado)', '{{PENDIENTE}}', 'Timing Summary - Route Design'],
], 'Datos de partida de la práctica 4.'));

// ---------------- 1. Diseño
add(H1('1. Diseño del conversor binario a BCD'));
add(BOX('Enunciado.', 'Diseñar un conversor de binario a BCD de acuerdo con los requisitos de las secciones «El algoritmo double dabble» y «Requisitos que tiene que cumplir el diseño».'));
add(P('El diseño sigue la arquitectura que propone la sección 5 del enunciado: un path de datos con el pipeline del algoritmo double dabble y un path de validación de salidas que retrasa `valid_in` lo mismo que el dato. Los dos caminos empiezan en registros de entrada y terminan en registros de salida.'));

add(H2('Paso 1. La entidad y los genéricos'));
add(P('La entidad tiene exactamente los puertos y genéricos de la sección 3.1. A cada genérico se le ha dado como valor por defecto la constante de `ctes_pkg` que pide el enunciado para la síntesis, de modo que Design Compiler puede elaborar `binary_to_bcd` sin pasarle `-parameters`. Con las constantes de `ctes_pkg`, los genéricos toman los valores de la tabla 2.'));
add(TAB([2700, 3300, 3026], [
  ['Genérico', 'Constante', 'Valor'],
  ['`gen_binary_bw`', '`C_BINARY_BW`', '14 (ceil(log2(10000)))'],
  ['`gen_bcd_bw`', '`C_BCD_BW`', '16 (4 dígitos × 4 bits)'],
  ['`gen_max_binary_value`', '`C_MAX_BINARY_VALUE`', '9999 (10^4 − 1)'],
  ['`gen_pipeline`', '`C_PIPELINE`', '14 bits a \'1\''],
], 'Genéricos de `binary_to_bcd` en la síntesis.'));
add(P('Como `gen_pipeline` es un `std_logic_vector` sin rango, dentro de la arquitectura se copia a la constante `c_pipeline` con rango `(gen_binary_bw - 1 downto 0)`. Así el bit `I` corresponde siempre a la etapa `I`, venga el vector con `downto` o con `to`. Tres `assert` comprueban en simulación que `gen_pipeline` tiene `gen_binary_bw` bits, que tiene al menos un \'1\' y que `gen_bcd_bw` vale `C_BCD_BW`, que es la anchura con la que trabaja `f_double_dabble_normalize_nibble_array`.'));

add(H2('Paso 2. Registros de entrada y saturación'));
add(P('El proceso `p_input_reg` registra `valid_in` en `reg_valid_in` y `binary_in` en `reg_binary_in`. Antes de guardar el dato lo compara con `gen_max_binary_value`: si `binary_in` es mayor, se guarda 9999. De esta forma `reg_binary_in` nunca supera el valor máximo, como exige la sección 5.2.'));

add(H2('Paso 3. Una etapa del pipeline: normalizar y desplazar'));
add(P('Lo que pasa de una etapa a la siguiente es un record con los dígitos BCD que se van construyendo y los bits binarios que aún no se han consumido:'));
add(CODE(['type t_pipeline_data is record', '    temp_bcd       : std_logic_vector(gen_bcd_bw - 1 downto 0);', '    temp_binary_in : std_logic_vector(gen_binary_bw - 1 downto 0);', 'end record;']));
add(P('Hay cinco arrays de `gen_binary_bw` elementos de este tipo: `s_entrada_pipeline`, `s_normalizacion`, `s_desplazamiento`, `reg_pipeline` y `s_salida_pipeline`. Un bucle `for generate` crea las 14 etapas. En la etapa `I`, la normalización usa la función de la librería, `f_double_dabble_normalize_nibble_array`, que suma 3 a cada dígito BCD que vale 5 o más. El desplazamiento mueve todo una posición a la izquierda: el bit más significativo de `temp_binary_in` entra por abajo en `temp_bcd`, y por abajo de `temp_binary_in` entra un \'0\'.'));
add(CODE(['s_desplazamiento(I).temp_bcd <=', '    s_normalizacion(I).temp_bcd(gen_bcd_bw - 2 downto 0) &', '    s_normalizacion(I).temp_binary_in(gen_binary_bw - 1);', 's_desplazamiento(I).temp_binary_in <=', '    s_normalizacion(I).temp_binary_in(gen_binary_bw - 2 downto 0) & \'0\';']));
add(P('La entrada de la etapa 0 tiene `temp_bcd` a cero y `temp_binary_in` igual a `reg_binary_in`. La entrada de la etapa `I+1` es la salida de la etapa `I`.'));

add(H2('Paso 4. El registro opcional de cada etapa'));
add(P('Dentro del `for generate` hay dos `if generate`. Si `c_pipeline(I)` vale \'1\', se crea el proceso `p_pipeline_reg`, que registra `s_desplazamiento(I)` en `reg_pipeline(I)`, y la salida de la etapa es ese registro. Si vale \'0\', no se crea ningún registro y la salida del desplazamiento pasa directa a la etapa siguiente. Con `C_PIPELINE` todo a \'1\' hay 14 registros de etapa, uno por cada bit del número binario.'));

add(H2('Paso 5. El path de validación de salidas'));
add(P('El retraso del pipeline es el número de unos de `gen_pipeline`, y lo calcula la función `f_count_ones_in_vector`, que el enunciado deja para el alumno. Recorre el vector con `input\'range` y cuenta los bits a \'1\':'));
add(CODE(['for I in input\'range loop', '    if input(I) = \'1\' then', '        v_count := v_count + 1;', '    end if;', 'end loop;']));
add(P('Con ese valor se declara `c_pipeline_delay` y el registro de desplazamiento `reg_valid_in_delayed(c_pipeline_delay - 1 downto 0)`. En cada flanco, el bit 0 toma `reg_valid_in` y cada bit `I` toma el bit `I-1`. El último bit sale con el mismo retraso que el dato del pipeline.'));

add(H2('Paso 6. Registros de salida y latencia'));
add(P('El proceso `p_output_reg` registra `s_salida_pipeline(13).temp_bcd` en `reg_bcd_out` y el último bit de `reg_valid_in_delayed` en `reg_valid_out`. La latencia total es la del pipeline más un ciclo del registro de entrada y otro del de salida: con 14 etapas registradas son 16 ciclos. Todos los registros del diseño tienen reset asíncrono activo a nivel bajo.'));

add(H2('Paso 7. Diagrama RTL'));
add(P('La figura 1, en la página siguiente, es el diagrama RTL de `binary_to_bcd` con `C_PIPELINE` todo a \'1\'. Cada proceso con reloj aparece como un registro y la lógica combinacional como nubes. La saturación es la comparación que hace `p_input_reg` antes de guardar el dato, y se dibuja como nube delante de `reg_binary_in`. Las etapas 2 a 12 son iguales a la 1 y se han omitido.'));
const FIG_SECTION_MARK = body.length; // la figura va en su propia sección apaisada
add(P('La tabla 3 cuenta los bits de cada registro tal como están descritos en el VHDL.'));
add(TAB([3300, 1400, 4326], [
  ['Registro', 'Bits', 'Función'],
  ['`reg_binary_in`', '14', 'Entrada registrada y saturada'],
  ['`reg_valid_in`', '1', 'Entrada registrada'],
  ['`reg_pipeline(0)` a `reg_pipeline(13)`', '14 × 30 = 420', 'Registro de cada etapa: 16 de `temp_bcd` y 14 de `temp_binary_in`'],
  ['`reg_valid_in_delayed`', '14', 'Path de validación'],
  ['`reg_bcd_out`', '16', 'Salida registrada'],
  ['`reg_valid_out`', '1', 'Salida registrada'],
  ['**Total en el VHDL**', '**466**', ''],
], 'Registros de `binary_to_bcd` descritos en el VHDL.'));
add(P('Muchos de estos bits tienen siempre el mismo valor. Por ejemplo, después de la etapa `I` los `I+1` bits bajos de `temp_binary_in` son ceros que han entrado por el desplazamiento. Design Compiler no implementa los biestables cuyo valor es constante, así que el número de biestables de `registros.rpt` será menor que 466. {{PENDIENTE: anotar aquí el número de registros.rpt y comprobar que hay 0 latches.}}'));

// ---------------- 2. Simulación
add(H1('2. Simulación en Questa'));
add(BOX('Enunciado.', 'La entidad `binary_to_bcd` debe cumplir el cronograma de la sección 3.5: con cuatro unos en `gen_pipeline`, una petición de conversión tarda 6 ciclos en salir (4 de las etapas y 2 de los registros de entrada y salida).'));
add(H2('Paso 1. El banco de pruebas'));
add(P('El banco `tb_binary_to_bcd` instancia el conversor con las constantes de `ctes_pkg` y tiene un genérico `g_pipeline` para probar otras configuraciones. Los estímulos van en tres fases:'));
add(BULLET('Fase 1: el cronograma del enunciado. Entran 7 y 42 en ciclos seguidos, un ciclo sin `valid_in` y después 999.'));
add(BULLET('Fase 2: todos los valores de 14 bits, de 0 a 16383, uno por ciclo. Los mayores que 9999 tienen que salir como 9999.'));
add(BULLET('Fase 3: 3000 valores pseudoaleatorios con huecos de 0, 1 o 2 ciclos en `valid_in`, para comprobar que `valid_out` sigue alineado con `bcd_out`.'));
add(P('Cada vez que `valid_out` vale \'1\', el banco compara `bcd_out` con un modelo de referencia que satura el valor y saca los cuatro dígitos con divisiones entre 10. También mide la latencia entre el primer `valid_in` y el primer `valid_out`, y al final comprueba que han salido tantos resultados como peticiones.'));
add(H2('Paso 2. Resultados'));
add(P('La simulación se lanza desde `sim/run` con `do ../bin/simular.do`. Los mensajes del transcript de Questa se resumen en la tabla 4.'));
add(TAB([4000, 2600, 2426], [
  ['Comprobación', 'Resultado', 'Esperado'],
  ['Latencia medida', '16 ciclos', '14 + 2 = 16'],
  ['Entrada 7', '`bcd_out` = 0007', '0007'],
  ['Entrada 42', '`bcd_out` = 0042', '0042'],
  ['Entrada 999', '`bcd_out` = 0999', '0999'],
  ['Conversiones sin error', '19387 de 19387', '3 + 16384 + 3000'],
], 'Resultados de la simulación en Questa con `C_PIPELINE` todo a \'1\'.'));
add(P('Los tres primeros resultados son los del cronograma de la sección 3.5. En el enunciado la latencia es de 6 ciclos porque el ejemplo usa cuatro etapas registradas; con las 14 de `C_PIPELINE` la cuenta es la misma, 14 + 2.'));
add(H2('Paso 3. Avisos del transcript'));
add(P('Al cargar la simulación aparecen 56 avisos `NUMERIC_STD.">=": metavalue detected`, todos en el instante 0 ns, iteración 0. En ese momento los registros todavía valen \'U\' porque el reset no ha actuado, y la comparación `>= 5` de `f_double_dabble_normalize_nibble` recibe esos valores. Son 4 dígitos por cada una de las 14 etapas. En la iteración siguiente el reset pone los registros a cero y los avisos no vuelven a salir.'));
add(P('{{PENDIENTE (opcional): simular en Questa otras configuraciones con vsim -gg_pipeline=... y añadir una tabla con la latencia de cada una.}}'));

// ---------------- 3. Síntesis
add(H1('3. Síntesis con Design Compiler'));
add(BOX('Enunciado.', 'Sintetizar el conversor en Design Compiler con los scripts que se ofrecen, con periodo de reloj de 10 ns, input delay de 2 ns, output delay de 2 ns y los genéricos iguales a las constantes de `ctes_pkg`. Entregar todos los reports de síntesis, incluido `log_sintesis.txt`. El diseño no debe inferir latches.'));
add(H2('Paso 1. Configuración de los scripts'));
add(P('En `syn/bin/fuentes.tcl`, los tres paquetes de `rtl/binary_to_bcd_lib/` van en `custom_library_sources` y `rtl/binary_to_bcd.vhd` en `work_sources`. El testbench no se incluye porque no es sintetizable. En `syn/bin/sintesis.tcl` se han rellenado las variables de la tabla 5; el resto del script queda como lo entrega el enunciado.'));
add(TAB([3300, 5726], [
  ['Variable', 'Valor'],
  ['`C_TOP`', '`binary_to_bcd`'],
  ['`C_ARQUITECTURA`', '`rtl`'],
  ['`C_LIBRERIA_TRABAJO`', '`work`'],
  ['`C_LIBRERIA_ADICIONAL`', '`binary_to_bcd_lib`'],
  ['`C_PERIODO_NS`', '10.0'],
  ['`C_RETARDO_ENTRADA_NS` / `C_RETARDO_SALIDA_NS`', '2.0 / 2.0'],
], 'Variables de `sintesis.tcl`.'));
add(P('La síntesis se lanza desde `syn/run` con `dc_shell -f ../bin/sintesis.tcl -output_log_file ../reports/log_sintesis.txt`.'));
add(H2('Paso 2. Resultados'));
add(P('{{PENDIENTE: completar con los datos de syn/reports/ tras la síntesis del jueves: biestables y latches (registros.rpt), área total (area.rpt), slack y camino crítico (timing.rpt), y los avisos de log_sintesis.txt y check_design.rpt.}}'));

// ---------------- 4. Vivado
add(H1('4. Implementación en la Basys 3 con Vivado'));
add(BOX('Enunciado.', 'Implementar el diseño en FPGA con Vivado siguiendo la sección «Implementación en FPGA». Entregar los reports «Utilization - Place Design» y «Timing Summary - Route Design» y los archivos `.bit` y `.bin` del bitstream.'));
add(H2('Paso 1. Conexión de bcd_out al display'));
add(P('El top `top_fpga_binary_bcd` se entrega con el display mostrando una palabra fija. Se ha sustituido por el proceso `p_display_chars_reg`: cada vez que `valid_out` vale \'1\', guarda en `reg_input_chars` los cuatro dígitos de `bcd_out`, pasando cada nibble a carácter con `f_basys3_nibble_to_char`. Mientras no llega otra conversión, el display mantiene la última. El índice 0 de `reg_input_chars` es el dígito de la derecha (ánodo `an[0]`), así que le corresponden las unidades, `bcd_out(3 downto 0)`. Tras el reset el display muestra 0000.'));
add(H2('Paso 2. Fuentes y librerías del proyecto'));
add(P('Como indica la sección 6.4, cada archivo tiene que importarse en su librería. La tabla 6 recoge el reparto. `xil_defaultlib` es el equivalente de `work` en Vivado.'));
add(TAB([3600, 5426], [
  ['Librería', 'Archivos'],
  ['`binary_to_bcd_lib`', '`ctes_pkg.vhd`, `subtypes_pkg.vhd`, `functions_pkg.vhd`'],
  ['`basys3_lib`', '`basys3_ctes_pkg.vhd`, `basys3_types_pkg.vhd`, `basys3_functions_pkg.vhd`, `basys3_components_pkg.vhd`, `debouncer.vhd`, `seven_segment_display_adapter.vhd`'],
  ['`xil_defaultlib`', '`binary_to_bcd.vhd`, `top_fpga_binary_bcd.vhd`'],
  ['restricciones', '`impl_fpga/constraints/constraints.xdc`'],
], 'Librerías de las fuentes en el proyecto de Vivado.'));
add(H2('Paso 3. Resultados de la implementación'));
add(P('{{PENDIENTE: completar con los reports de Vivado: LUT, registros y Block RAM de «Utilization - Place Design», y WNS, TNS y si se cumplen todas las restricciones de «Timing Summary - Route Design».}}'));
add(H2('Paso 4. Prueba en la placa'));
add(P('{{PENDIENTE: anotar las pruebas hechas en la Basys 3 (por ejemplo, 1234 en los interruptores y pulsar btnU; todos los interruptores a 1 para ver la saturación a 9999).}}'));

// ================= TOC estático (como en la práctica 2)
function tocLine(text, page, level) {
  return new Paragraph({
    tabStops: [{ type: TabStopType.RIGHT, position: 9026, leader: 'dot' }],
    spacing: { before: level === 0 ? 140 : 0, after: 40 }, indent: { left: level === 0 ? 0 : 400 },
    children: [new TextRun({ text, font: TNR, bold: level === 0, size: 24 }), new TextRun({ text: `\t${page ?? '?'}`, font: TNR, bold: level === 0, size: 24 })],
  });
}
const toc = [new Paragraph({ style: 'Title', children: [new TextRun({ text: 'Índice', font: TNR })] })];
for (const g of H2s) { toc.push(tocLine(g.h1, PAGES[g.h1], 0)); for (const s of g.items) toc.push(tocLine(s, PAGES[g.h1 + '|' + s], 1)); }

// ================= Portada
const cover = [
  new Paragraph({ spacing: { before: 2600 } }),
  new Paragraph({ alignment: AlignmentType.CENTER, children: [new ImageRun({ type: 'png', data: fs.readFileSync('logo.png'), transformation: { width: 400, height: 186 } })] }),
  new Paragraph({ spacing: { before: 600 } }),
  new Paragraph({ style: 'Title', alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'Práctica 4 · Conversor binario a BCD: Respuestas', font: TNR })] }),
  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 400 }, children: [new TextRun({ text: 'Métodos de Diseño Electrónico · Curso 2026-2027', font: TNR, size: 22 })] }),
  new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'Diego Orellana', font: TNR })] }),
  new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'Iñigo Zubieta', font: TNR })] }),
];

// ================= Figura apaisada
const img = fs.readFileSync('diagrama.png');
const figura = [
  new Paragraph({ alignment: AlignmentType.CENTER, keepNext: true, children: [new ImageRun({ type: 'png', data: img, transformation: { width: 1000, height: Math.round(1000 * 1290 / 3510) } })] }),
  CAP('Figura', 'Diagrama RTL de `binary_to_bcd` con `C_PIPELINE` todo a \'1\'.'),
];

const footer = new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ children: [PageNumber.CURRENT], font: TNR, size: 20 })] })] });
const portrait = { page: { size: { width: 11906, height: 16838 }, margin: { top: 1440, right: 1440, bottom: 1300, left: 1440 } } };
const landscape = { page: { size: { width: 11906, height: 16838, orientation: PageOrientation.LANDSCAPE }, margin: { top: 700, right: 700, bottom: 800, left: 700 } } };

const doc = new Document({
  creator: 'Diego Orellana, Iñigo Zubieta',
  title: 'Práctica 4 · Conversor binario a BCD: Respuestas',
  styles: {
    default: { document: { run: { font: TNR, size: 24 } } },
    paragraphStyles: [
      { id: 'Title', name: 'Title', basedOn: 'Normal', next: 'Normal', quickFormat: true, run: { font: TNR, size: 36, bold: true }, paragraph: { spacing: { before: 0, after: 240 }, keepNext: true } },
      { id: 'Heading1', name: 'Heading 1', basedOn: 'Normal', next: 'Normal', quickFormat: true, run: { font: TNR, size: 30, bold: true }, paragraph: { spacing: { before: 360, after: 160 }, keepNext: true, outlineLevel: 0 } },
      { id: 'Heading2', name: 'Heading 2', basedOn: 'Normal', next: 'Normal', quickFormat: true, run: { font: TNR, size: 25, bold: true }, paragraph: { spacing: { before: 220, after: 100 }, keepNext: true, outlineLevel: 1 } },
      { id: 'Caption', name: 'caption', basedOn: 'Normal', next: 'Normal', quickFormat: true, run: { font: TNR, size: 20, italics: true, color: CAPBLUE }, paragraph: { spacing: { before: 80, after: 240 } } },
    ],
  },
  numbering: { config: [{ reference: 'bul', levels: [{ level: 0, format: 'bullet', text: '•', alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 600, hanging: 300 } } } }] }] },
  sections: [
    { properties: { ...portrait }, children: cover },
    { properties: { ...portrait, type: SectionType.NEXT_PAGE, page: { ...portrait.page, pageNumbers: { start: 2 } } }, footers: { default: footer }, children: [...toc, new Paragraph({ children: [new PageBreak()] }), ...body.slice(0, FIG_SECTION_MARK)] },
    { properties: { ...landscape, type: SectionType.NEXT_PAGE }, footers: { default: footer }, children: figura },
    { properties: { ...portrait, type: SectionType.NEXT_PAGE }, footers: { default: footer }, children: body.slice(FIG_SECTION_MARK) },
  ],
});
Packer.toBuffer(doc).then((b) => { fs.writeFileSync('raw.docx', b); fs.writeFileSync('headings.json', JSON.stringify(H2s)); console.log('ok', nTab, 'tablas', nFig, 'figuras'); });
